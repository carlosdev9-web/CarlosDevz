fun main() {
    println("Welcome to SSTV Robot36!")
    // Lógica de la aplicación
}
