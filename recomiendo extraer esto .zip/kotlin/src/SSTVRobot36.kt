class SSTVRobot36 {
    fun encodeSSTV(message: String) {
        // Implementar la lógica de codificación SSTV
    }

    fun decodeSSTV(signal: String) {
        // Implementar la lógica de decodificación SSTV
    }
}
ass SSTVRobot36 {
	    fun start() {
		            println("SSTV Robot36 is starting...")
			            // Aquí va la lógica específica del modo Robot36
				    //     }
				    //     }
