rootProject.name = "sstv_project"
