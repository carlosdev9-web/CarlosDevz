plugins {
	    kotlin("jvm") version "1.8.21" // Asegúrate de que la versión de Kotlin sea compatible
    }

    java {
	        toolchain {
			        languageVersion.set(JavaLanguageVersion.of(21))  // Usamos Java 21
				    }
			    }

			    repositories {
				        mavenCentral()
				}

				dependencies {
					    implementation(kotlin("stdlib"))
				    }
