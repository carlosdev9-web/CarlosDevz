package com.sstv;

public class Main {
    public static void main(String[] args) {
        System.out.println("Aplicación ejecutada con éxito");
    }
}
