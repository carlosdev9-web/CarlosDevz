fun main() {
    println("SSTV Android Test - Kotlin is working!")
}

