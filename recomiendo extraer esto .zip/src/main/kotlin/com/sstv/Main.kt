package com.sstv

fun main() {
    println("Aplicación ejecutada con éxito")
}
